<?php

namespace sDocs\sDocs;

$users = array(
    'user' => array('pass' => 'user', 'realname' => 'Иванов И.В.', 'role' => 'boss'),
    'user1' => array('pass' => 'user1', 'realname' => 'Петров П.П.', 'role' => 'manager'),
    'user2' => array('pass' => 'user2', 'realname' => 'Сидоров С.С.', 'role' => 'user'),
);